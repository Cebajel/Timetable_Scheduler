import gurobipy as gp
import numpy as np
from gurobipy import GRB
import pandas, math
from copy import deepcopy
import classes


def read_input_excel(file):
    # second_file = ""
    second_file = "-test"
    courses = pandas.read_excel(file, "Courses"+second_file)
    columns = courses.columns
    courses_dict = {}
    student_dict = {}
    instructor_dict = {}
    venue_dict = {}
    for value in courses.iterrows():
        value = value[1]
        new_course = classes.Course(value, columns)
        instructors = [i.strip() for i in value[columns[2]].split("\n")]
        for i in instructors:
            if i in instructor_dict:
                new_course.add_instructor(instructor_dict[i])
                instructor_dict[i].add_course(new_course)
            else:
                new_instructor = classes.Instructor(i)
                instructor_dict[i] = new_instructor
                new_instructor.add_course(new_course)
                new_course.add_instructor(new_instructor)
        courses_dict[new_course.code] = new_course

    registrations = pandas.read_excel(file, "Registrations"+second_file)
    columns = registrations.columns

    for value in registrations.iterrows():
        value = value[1]
        if value[1] in student_dict.keys():
            student_dict[value[columns[1]]].add_course(courses_dict[value[columns[0]]],  int(value[columns[3]]))
            courses_dict[value[columns[0]]].add_student(student_dict[value[columns[1]]],  int(value[columns[3]]))
        else:
            current_student = classes.Student(value[columns[1]])
            new_student = deepcopy(current_student)
            new_student.add_course(courses_dict[value[columns[0]]], int(value[columns[3]]))
            student_dict[value[columns[1]]] = new_student
            courses_dict[value[columns[0]]].add_student(new_student, int(value[columns[3]]))
            del current_student

    venues = pandas.read_excel(file, "Venues"+second_file)
    columns = venues.columns

    for value in venues.iterrows():
        value = value[1]
        current_venue = classes.Venue(str(value[columns[0]]).strip(), value[columns[4]], value[columns[5]], value[columns[6]])
        venue_dict[str(value[columns[0]]).strip()] = deepcopy(current_venue)
        del current_venue

    return courses_dict, student_dict, instructor_dict, venue_dict

def initialize_parameters(file_name):
    # second_file = ""
    # second_file = "-test"
    courses_dict, student_dict, instructor_dict, venue_dict = read_input_excel(file_name)
    number_of_students = len(student_dict)
    number_of_instructors = len(instructor_dict)
    number_of_venues = len(venue_dict)
    number_of_working_days = 7
    slots = 8
    venue_types = {}
    venue_type_campus = {}
    campus_list = sorted(set([i.campus_type for i in venue_dict.values()]))
    number_of_campuses = len(campus_list)

    for _, venue in venue_dict.items():
        temp1 = venue.type
        temp2 = venue.campus_type
        if temp1 in venue_types:
            venue_types[temp1] += 1
        else:
            venue_types[temp1] = 1

        if temp1 not in venue_type_campus:
            venue_type_campus[temp1] = {i:0 for i in campus_list}

        venue_type_campus[temp1][temp2] += 1

    venue_types_list = list(sorted(venue_types.keys()))
    lab_types_list = venue_types_list[1:] 
    student_list = list(sorted(student_dict.keys(), key=lambda x: int(x)))
    instructor_list = list(sorted(instructor_dict.keys()))
    venue_list = list(sorted(venue_dict.keys(), key=lambda x: (venue_dict[x].type, venue_dict[x].campus_type)))
    venue_setups = np.array([venue_dict[i].number_of_setups for i in venue_list])
    venue_campus = np.array([venue_dict[i].campus_type for i in venue_list])

    temp_values = [value for value in courses_dict.values()]
    for course in temp_values:
        current_course_campus = course.campus_type
        current_course_classrooms = np.where(venue_campus[:venue_types[0]] == current_course_campus)
        current_course_max_classroom_strength = np.max(venue_setups[current_course_classrooms])
        if course.get_strength() > current_course_max_classroom_strength and (course.L + course.T) > 0 :
            strength_factor = math.ceil(course.get_strength() / current_course_max_classroom_strength)
            new_strength = course.get_strength() // strength_factor
            temp_students_list = list(sorted(course.students.keys(), key=lambda x: x.rollnumber))
            for i in range(strength_factor) :
                new_course = course.copy()
                new_course.code = new_course.code + "/L" + str(i)
                new_course.P = 0
                new_course.students = {j : course.students[j] for j in temp_students_list[new_strength*i : new_strength*i + new_strength]}
                courses_dict[new_course.code] = new_course
                with open("Results/Course_Rollnumbers.txt", "a") as file:
                    file.write(f"\n{new_course.code} : { {i.rollnumber:priority for i,priority in new_course.students.items()} }\n")

                for student, priority in new_course.students.items() :
                    if course.P == 0 :
                        del course.students[student]
                        del student.courses[course]
                    student.add_course(new_course, priority)

                for instructor in new_course.instructors:
                    if course.P == 0 :
                        course.instructors.remove(instructor)
                        instructor.courses.remove(course)
                    instructor.add_course(new_course)
            course.L = 0
            course.T = 0
            if course.P == 0 :
                del courses_dict[course.code]
    del temp_values
    # core_courses = np.zeros((number_of_students, number_of_courses))
    # exit(1)
    course_list = list(sorted(courses_dict.keys()))
    # print({course : courses_dict[course].get_strength() for course in course_list})
    # print({course : courses_dict[course].get_LTP() for course in course_list})
    # exit(1)
    course_campus = np.array([courses_dict[i].campus_type for i in course_list])
    number_of_courses = len(courses_dict)
    course_lab = np.zeros((number_of_courses, 2))
    students_Courses = np.zeros((number_of_students, number_of_courses))
    instructors_Courses = np.zeros((number_of_instructors, number_of_courses))
    course_credits = np.zeros((number_of_courses, 3))
    student_course_priority = np.zeros((number_of_students, number_of_courses)) - 1
    non_minor_core_course = np.zeros((number_of_students, number_of_courses))
    full_sem_courses = []
    pre_half_sem_courses = []
    post_half_sem_courses = []


    # registrations = pandas.read_excel(file_name, "Registrations"+second_file)
    # columns = registrations.columns
    for i, j in enumerate(student_list):
        # value = value[1]
        # course_index = course_list.index(value[columns[0]].strip())
        # student_index = student_list.index(value[columns[1]])
        # print(value)
        # core_courses[student_index][course_index] = 1 if value[columns[-2]].strip() == "Yes" else -1

        for course in student_dict[j].courses :
            course_index = course_list.index(course.code)
            type_of_course = student_dict[j].courses[course]
            student_course_priority[i][course_index] = type_of_course
            non_minor_core_course[i][course_index] = 1 if type_of_course == 0 else 0
    # del registrations, columns



    non_minor_core_course = np.sum(non_minor_core_course, axis=0)
    non_minor_core_course = np.where(non_minor_core_course == 0, 0, 1)

    for i, j in enumerate(student_list):
        for k in student_dict[j].courses:
            students_Courses[i][course_list.index(k.code)] = 1

    for i, j in enumerate(instructor_list):
        for k in instructor_dict[j].courses:
            instructors_Courses[i][course_list.index(k.code)] = 1

    # core_courses = np.sum(students_Courses, axis=0)
    course_strength = np.sum(students_Courses, axis=0)

    for i, j in enumerate(course_list):
        course_lab[i][0] = courses_dict[j].group_size
        course_lab[i][1] = courses_dict[j].lab_type

        L, T, P = courses_dict[j].get_LTP()
        course_credits[i][0] = L
        course_credits[i][1] = T
        course_credits[i][2] = P
        # course_credits[i][2] = 0

        if courses_dict[j].minor:
            non_minor_core_course[i] = 2

        if course_strength[i] == 0:
            course_credits[i][0] = 0
            course_credits[i][1] = 0
            course_credits[i][2] = 0

        my_type = courses_dict[j].duration

        if my_type == "F":
            full_sem_courses.append(i)
        elif my_type == "H1":
            pre_half_sem_courses.append(i)
        else:
            post_half_sem_courses.append(i)

    course_credits = np.c_[course_credits, np.sum(course_credits, axis=1)]
        # print(course_credits[i][2])

        # if courses_dict[j].mode == 'Online':
        #     course_strength[i] = 0

    
    # print(course_credits)
    # exit(1)
    
    # number_of_labs,
    # students_Courses
    #  core_courses, 

    # x1 = np.where(student_course_priority==0, 1, 0)
    # x1 = np.sum(x1, axis=0)
    # x1 = np.where(x1 > 0)
    # x1 = x1[0]
    # for i in x1:
    #     print(course_list[i], end=" ")

    # exit(1)
    # my_index = 66
    # print(f"{my_index} : {course_list[my_index]}")
    # exit(1)


    # inputs = [number_of_working_days, slots, number_of_venues, number_of_courses, number_of_students,
    #  instructors_Courses, number_of_instructors, course_credits, venue_dict, venue_list,
    #  course_list, venue_setups, course_strength, full_sem_courses, pre_half_sem_courses, post_half_sem_courses,
    #  venue_types, venue_types_list, lab_types_list, course_lab, student_course_priority, non_minor_core_course]
    
    parameters = classes.Params()
    parameters.number_of_working_days = number_of_working_days
    parameters.slots = slots
    parameters.number_of_courses = number_of_courses
    parameters.number_of_venues = number_of_venues
    parameters.number_of_students = number_of_students
    parameters.instructors_Courses = instructors_Courses
    parameters.number_of_instructors = number_of_instructors
    parameters.course_credits = course_credits
    parameters.venue_dict = venue_dict
    parameters.venue_list = venue_list
    parameters.course_list = course_list
    parameters.venue_setups = venue_setups
    parameters.course_strength = course_strength
    parameters.full_sem_courses = full_sem_courses
    parameters.pre_half_sem_courses = pre_half_sem_courses
    parameters.post_half_sem_courses = post_half_sem_courses
    parameters.venue_types = venue_types
    parameters.venue_types_list = venue_types_list
    parameters.lab_types_list = lab_types_list
    parameters.course_lab = course_lab
    parameters.student_course_priority = student_course_priority
    parameters.non_minor_core_course = non_minor_core_course
    parameters.venue_type_campus = venue_type_campus
    parameters.campus_list = campus_list
    parameters.number_of_campuses = number_of_campuses
    parameters.course_campus = course_campus
    parameters.venue_campus = venue_campus
    parameters.student_list = student_list
    parameters.courses_dict = courses_dict
    parameters.student_dict = student_dict
    parameters.instructor_dict = instructor_dict
    parameters.venue_dict = venue_dict
    parameters.instructor_list = instructor_list



    return parameters


def initialize_model(parameters : classes.Params):
    my_model = gp.Model("Timetable")
    my_model.Params.LogFile = "m.log"
    # my_model.setParam("LogToConsole", 0)
    my_model.Params.TimeLimit = float('infinity')
    # my_model.Params.MIPGap = 3e-2
    schedule = my_model.addMVar((parameters.number_of_working_days, parameters.slots, parameters.number_of_venues,
                                    parameters.number_of_courses), vtype=GRB.BINARY,
                                name="time")
    return my_model, schedule


def constr_One_Venue_One_Course(my_model, schedule, parameters : classes.Params) :
    # x1 = schedule.sum(axis=3)
    x1 = schedule[:, :, :parameters.venue_types[parameters.venue_types_list[0]], parameters.full_sem_courses + parameters.pre_half_sem_courses].sum(axis=3)
    my_model.addConstrs(((x1[i, j, k] <= 1) for i in range(parameters.number_of_working_days)
                         for j in range(parameters.slots) 
                         for k in range(parameters.venue_types[parameters.venue_types_list[0]])), name="One_Venue_One_Course_Pre_Sem")
    
    x1 = schedule[:, :, :parameters.venue_types[parameters.venue_types_list[0]], parameters.full_sem_courses + parameters.post_half_sem_courses].sum(axis=3)
    my_model.addConstrs(((x1[i, j, k] <= 1) for i in range(parameters.number_of_working_days)
                         for j in range(parameters.slots) 
                         for k in range(parameters.venue_types[parameters.venue_types_list[0]])), name="One_Venue_One_Course_Post_Sem")
    
    return

def constr_No_course_Overlap_Student(my_model, schedule, parameters : classes.Params):
    
    x1 = schedule.sum(axis=2)
    # for i in range(parameters.number_of_working_days) :
    #     for j in range(parameters.slots) :
    #         for k in range(parameters.number_of_students) :
    #             courses_1 = np.intersect1d(parameters.full_sem_courses + parameters.pre_half_sem_courses, np.where(parameters.student_course_priority[k] == 0))
    #             courses_2 =  np.intersect1d(parameters.full_sem_courses + parameters.post_half_sem_courses, np.where(parameters.student_course_priority[k] == 0))
    #             if courses_1.size > 0:
    #                 my_model.addConstr(
    #                     x1[i, j, courses_1].sum() <= 1,
    #                     name="No_course_Overlap_Student_Pre_Sem_Core")
    
    #             if courses_2.size > 0:
    #                 my_model.addConstr(
    #                     x1[i, j,courses_2].sum() <= 1,
    #                     name="No_course_Overlap_Student_Post_Sem_Core")

    constrs = []
    least_priority = int(np.max(parameters.student_course_priority))

    for priority in range(0, least_priority + 1):
        temp1 = []
        temp2 = []
        for i in range(parameters.number_of_working_days):
            for j in range(parameters.slots):
                for k in range(parameters.number_of_students):
                    courses_1 = np.intersect1d(parameters.full_sem_courses + parameters.pre_half_sem_courses, np.where(parameters.student_course_priority[k] == priority))
                    courses_2 = np.intersect1d(parameters.full_sem_courses + parameters.post_half_sem_courses, np.where(parameters.student_course_priority[k] == priority))
                    if courses_1.size > 0:
                        temp1.append(my_model.addConstr(
                            x1[i, j, courses_1].sum() <= 1,
                            name="No_course_Overlap_Student_Pre_Sem" + "_" + str(priority)))
                    
                    if courses_2.size > 0:
                        temp2.append(my_model.addConstr(
                            x1[i, j, courses_2].sum() <= 1,
                            name="No_course_Overlap_Student_Post_Sem" + "_" + str(priority)))
                    
        if priority != 0 :          
            constrs.append([temp1, temp2])

    return constrs


def constr_No_course_Overlap_Professor(my_model, schedule, parameters : classes.Params):
    x1 = schedule[:, :, :, parameters.full_sem_courses + parameters.pre_half_sem_courses].sum(axis=2)
    x2 = schedule[:, :, :, parameters.full_sem_courses + parameters.post_half_sem_courses].sum(axis=2)
    for i in range(parameters.number_of_working_days):
        for j in range(parameters.slots):
            for k in range(parameters.number_of_instructors):
                my_model.addConstr(
                    (x1[i, j] * parameters.instructors_Courses[k][parameters.full_sem_courses + parameters.pre_half_sem_courses]).sum() <= 1, 
                    name="No_course_Overlap_Professor_Pre_Sem")  

                my_model.addConstr(
                    (x2[i, j] * parameters.instructors_Courses[k][parameters.full_sem_courses + parameters.post_half_sem_courses]).sum() <= 1, 
                    name="No_course_Overlap_Professor_Post_Sem") 

    return

def constr_One_Slot_Course_Once(my_model, schedule, parameters : classes.Params):
    # I will add groups later
    x1 = schedule.sum(axis=2)
    my_model.addConstrs(((x1[i, j, k] <= 1) for i in range(parameters.number_of_working_days)
                         for j in range(parameters.slots) for k in range(parameters.number_of_courses)), name="One_Slot_Course_Once")
    return
    
# number_of_labs,
def constr_Course_only_Once_a_day(my_model, schedule, parameters : classes.Params):
    x1 = schedule[:,:,:parameters.venue_types[parameters.venue_types_list[0]], :].sum(axis=2)
    x2 = x1.sum(axis=1)
    my_model.addConstrs(((x2[i, j] <= 1) for i in range(parameters.number_of_working_days) for j in range(parameters.number_of_courses)),
                        name="Course_only_Once_a_day_0")
    
    x1 = schedule.sum(axis=2)
    x2 = x1.sum(axis=1)
    my_model.addConstrs(((x2[i, j] <= (parameters.course_credits[j, -2] + 1)) 
                            for i in range(parameters.number_of_working_days) for j in range(parameters.number_of_courses)),
                        name="Course_only_Once_a_day_1")
    return

# def constr_Lab_only_Once_a_day(my_model, schedule, number_of_working_days, number_of_courses, number_of_labs):
#     x2 = schedule[:,:, -number_of_labs:, :].sum(axis=2)
#     x3 = x2.sum(axis=1)
#     my_model.addConstrs(((x3[i, j] <= 3) for i in range(number_of_working_days) for j in range(number_of_courses)),
#                         name="Course_only_Once_a_day")
#     return

def constr_Total_Credits_of_core_Course(my_model, schedule, parameters : classes.Params):
    x1 = schedule.sum(axis=2)
    x2 = x1.sum(axis=1)
    x2 = x2.sum(axis=0)
    my_model.addConstrs(
        ((x2[i] == parameters.course_credits[i, -1]) for i in range(parameters.number_of_courses)),
                        name="Total_Credits_of_core_Course"
                        )
    return

# number_of_labs,
def constr_Total_lab_hours_of_Course(my_model, schedule, parameters : classes.Params):
    my_sum = parameters.venue_types[parameters.venue_types_list[0]]
    for lab in parameters.lab_types_list:
        x1 = schedule[:, :, my_sum: my_sum + parameters.venue_types[lab], :]
        my_sum += parameters.venue_types[lab]
        x2 = x1.sum(axis=2)
        x2 = x2.sum(axis=1)
        x2 = x2.sum(axis=0)
        my_model.addConstrs(((x2[i] == parameters.course_credits[i, -2]) 
                             if parameters.course_lab[i][1] == lab else (x2[i] == 0) for i in range(parameters.number_of_courses) ),
                            name="Total_lab_hours_of_Course")
    return

def constr_venue_setups(my_model, schedule, parameters : classes.Params):
    x1 = schedule.sum(axis=1)
    x1 = x1.sum(axis=0)
    my_model.addConstrs(((x1[i, j] == 0) for i in range(parameters.number_of_venues) for j in range(parameters.number_of_courses) if
                         parameters.course_strength[j] > parameters.venue_setups[i] * parameters.course_lab[j][0]), name="venue_setups")
    return


def constrs_Allowed_Lab_Time(my_model, schedule, parameters : classes.Params):
    my_sum = parameters.venue_types[parameters.venue_types_list[0]]
    for lab in parameters.lab_types_list:
        total_venues = parameters.venue_types[lab]
        x1 = schedule[:, :, my_sum : my_sum + total_venues, :]
        my_sum += total_venues
        # x11 = x4.sum(axis=3)

        my_model.addConstrs(
            ( (gp.quicksum(x1[i, j, k, l] for j in range(parameters.slots) ) <= parameters.course_credits[l, -2]) if parameters.course_lab[l][1] == lab 
              else (gp.quicksum(x1[i, j, k, l] for j in range(parameters.slots) ) == 0)
              for i in range(parameters.number_of_working_days)
              for k in range(total_venues) for l in range(parameters.number_of_courses)),
              name="Hours_A_day_of_Lab")

        y = my_model.addMVar((parameters.number_of_working_days, total_venues, parameters.number_of_courses,  parameters.slots+1), vtype=GRB.BINARY)
        # constr_indicator_1(my_model, number_of_working_days, number_of_labs, number_of_courses, y)
        
        # constr_indicator_2(my_model, number_of_working_days, number_of_labs, number_of_courses, y)


        my_model.addConstrs(
            ((gp.quicksum(y[i, j, k, l] for l in range(parameters.slots+1)) == 1) for i in range(parameters.number_of_working_days) for j in range(total_venues)
            for k in range(parameters.number_of_courses) if parameters.course_lab[k][1] == lab ),
            name="indicator_0")

        my_model.addConstrs(((y[i, k, l, parameters.slots].item() == 1) >> (gp.quicksum(x1[i, j, k, l] for j in range(parameters.slots)) == 0)
                            for i in range(parameters.number_of_working_days) for k in range(total_venues) for l in range(parameters.number_of_courses) 
                            if parameters.course_lab[l][1] == lab ),
                            name="Allowed_Lab_Time_10")

        # for l in range(number_of_courses):

        #     current_credits = int(course_credits[l][-2])
        #     if current_credits > 0:
        #         for t in range(0, 5 - int(int(course_credits[l][-2]))):

        my_model.addConstrs(
            ( (y[i, k, l, t].item() == 1) >> (gp.quicksum(x1[i, j, k, l] for j in range(t, t + int(parameters.course_credits[l][-2]))) == int(parameters.course_credits[l][-2]))
                            for i in range(parameters.number_of_working_days) 
                            for k in range(total_venues) for l in range(parameters.number_of_courses)
                            for t in range(0, 5 - int(parameters.course_credits[l][-2]))  
                            if int(parameters.course_credits[l][-2]) > 0 and parameters.course_lab[l][1] == lab ),
                            name="Allowed_Lab_Time_0")
                    
        my_model.addConstrs(
            ((gp.quicksum(y[i, j, l, t] for t in range(5 - int(parameters.course_credits[l][-2]), 4)) == 0) 
                for i in range(parameters.number_of_working_days) for j in range(total_venues)
                for l in range(parameters.number_of_courses) 
                if int(parameters.course_credits[l][-2]) > 0 and parameters.course_lab[l][1] == lab  ),
            name="indicator_1")
                    
                # for t in range(4, 9 - int(int(course_credits[l][-2]))):
        my_model.addConstrs(((y[i, k, l, t].item() == 1) >> 
                                (gp.quicksum(x1[i, j, k, l] for j in range(t, t + int(parameters.course_credits[l][-2]))) == int(parameters.course_credits[l][-2]))
                                for i in range(parameters.number_of_working_days) for k in range(total_venues)
                                for l in range(parameters.number_of_courses) 
                                for t in range(4, parameters.slots + 1 - int(parameters.course_credits[l][-2])) 
                                if int(parameters.course_credits[l][-2]) > 0 and parameters.course_lab[l][1] == lab ),
                            name="Allowed_Lab_Time_1")
                    
        my_model.addConstrs(
            ((gp.quicksum(y[i, j, l, t] for t in range(parameters.slots + 1 - int(parameters.course_credits[l][-2]), parameters.slots)) == 0) 
            for i in range(parameters.number_of_working_days) for j in range(total_venues)
            for l in range(parameters.number_of_courses) 
            if int(parameters.course_credits[l][-2]) > 0 and parameters.course_lab[l][1] == lab ),
            name="indicator_2")
                
    return


def constrs_Non_Minor_Core_Course(my_model, schedule, parameters : classes.Params):
    x1 = schedule.sum(axis=2)
    for _, k1 in np.ndenumerate(np.where(parameters.non_minor_core_course == 1)):
        for _, k2 in np.ndenumerate(np.where(parameters.non_minor_core_course == 2)):
            my_model.addConstrs(
                ((x1[i, j, k1] + x1[i, j, k2] <= 1) for i in range(parameters.number_of_working_days) for j in range(parameters.slots)),
                name="Non_Minor_Core_Course"
            )

    return


def constrs_Course_Campus(my_model, schedule, parameters : classes.Params):
    x = schedule.sum(axis=1)
    x = x.sum(axis=0)
    my_model.addConstrs(
        ((x[i, j] == 0) for i in range(parameters.number_of_venues) 
            for j in range(parameters.number_of_courses) if parameters.venue_campus[i] != parameters.course_campus[j]),
        name="Campus_Constraint"
    )

    return


def constrs_Student_Campus(my_model, schedule, parameters : classes.Params) :
    x = schedule.sum(axis=2)
    y = my_model.addMVar((parameters.number_of_working_days, parameters.slots, parameters.number_of_courses), vtype=GRB.BINARY)
    my_model.addConstrs(
        ((x[i, j, k] == y[i, j, k]) for i in range(parameters.number_of_working_days) 
        for j in range(parameters.slots) for k in range(parameters.number_of_courses)),
        name = "Conditional_Constraint"
    )

    for student in range(parameters.number_of_students):
        student_courses = parameters.student_course_priority[student]
        student_courses = np.where(student_courses != -1)
        for campus in parameters.campus_list:
            current_campus_courses = np.where(parameters.course_campus == campus)
            not_current_campus_courses = np.where(parameters.course_campus != campus)
            current_campus_student_courses = list(np.intersect1d(student_courses, current_campus_courses))
            not_current_campus_student_courses = np.intersect1d(student_courses, not_current_campus_courses)

            # for l in current_campus_student_course:
                # for j in range(parameters.slots - 1):
            
            if len(current_campus_student_courses)*not_current_campus_student_courses.size > 0:
                my_model.addConstrs(
                    (((y[i, j, k].item() == 1) >> (gp.quicksum(x[i, j+1, not_current_campus_student_courses]) == 0)) 
                    for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)
                    for k in current_campus_student_courses),
                    name = "Student_Campus_Constraint"
                )

    return


def constrs_Professor_Campus(my_model, schedule, parameters : classes.Params) :
    x = schedule.sum(axis=2)
    y = my_model.addMVar((parameters.number_of_working_days, parameters.slots, parameters.number_of_courses), vtype=GRB.BINARY)
    my_model.addConstrs(
        ((x[i, j, k] == y[i, j, k]) for i in range(parameters.number_of_working_days) 
        for j in range(parameters.slots) for k in range(parameters.number_of_courses)),
        name = "Conditional_Constraint"
    )

    for instructor in range(parameters.number_of_instructors):
        instructor_courses = parameters.instructors_Courses[instructor]
        instructor_courses = np.where(instructor_courses == 1)
        for campus in parameters.campus_list:
            current_campus_courses = np.where(parameters.course_campus == campus)
            not_current_campus_courses = np.where(parameters.course_campus != campus)
            current_campus_instructor_courses = list(np.intersect1d(instructor_courses, current_campus_courses))
            not_current_campus_instructor_courses = np.intersect1d(instructor_courses, not_current_campus_courses)

            # for l in current_campus_student_course:
                # for j in range(parameters.slots - 1):
            
            if len(current_campus_instructor_courses)*not_current_campus_instructor_courses.size > 0:
                my_model.addConstrs(
                    (((y[i, j, k].item() == 1) >> (gp.quicksum(x[i, j+1, not_current_campus_instructor_courses]) == 0)) 
                    for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)
                    for k in current_campus_instructor_courses),
                    name = "Professor_Campus_Constraint"
                )

    return


def sec_constrs_non_overlapping_periods(my_model, schedule, parameters : classes.Params) :
    classrooms = parameters.venue_types[parameters.venue_types_list[0]]
    x = schedule[:, :, :classrooms, :]
    x = x.sum(axis=2)
    x = x.sum(axis=0)
    
    constraint = my_model.addConstrs(
        ((x[i, j] <= 1) for i in range(parameters.slots) for j in range(parameters.number_of_courses)),
        name="Sec_Constraint_Of_Non_Overlapping_Slots"
    )
    return constraint


def sec_constrs_core_courses_before_break(my_model, schedule, parameters : classes.Params):
    x1 = np.where(parameters.student_course_priority==0, 1, 0)
    x1 = np.sum(x1, axis=0)
    x1 = np.where(x1 > 0)
    x1 = x1[0]
    number_of_core_courses = len(x1)
    # x1 contains indices for core courses

    x1 = schedule[:, (parameters.slots - 1):, :, x1]
    x1 = x1.sum(axis=2)
    x1 = x1.sum(axis=1)
    x1 = x1.sum(axis=0)

    constraint = my_model.addConstrs(
        ((x1[i] == 0) for i in range(number_of_core_courses)),
        name="Sec_Constraint_Of_Core_Courses_In_Morning"
    )
    return constraint


def sec_constrs_course_having_same_venue(my_model, schedule, parameters : classes.Params):
    x = schedule[:, :, :parameters.venue_types[0], :].sum(axis=1)
    x = x.sum(axis=0)
    y = my_model.addMVar((parameters.venue_types[0], parameters.number_of_courses), vtype=GRB.BINARY)

    constraint = []
    constraint.append(my_model.addConstrs(
        (((y[i, j].item() == 1) >> (x[i, j] >= np.sum(parameters.course_credits[j][:2]))) 
         for i in range(parameters.venue_types[0]) 
         for j in range(parameters.number_of_courses)),
         name = "Conditional Constraint_1" 
    ))

    constraint.append(my_model.addConstrs(
        (((y[i, j].item() == 0) >> (x[i, j] == 0)) 
         for i in range(parameters.venue_types[0]) 
         for j in range(parameters.number_of_courses)),
         name = "Conditional Constraint_2" 
    ))

    # temp_array = np.arange(parameters.venue_types[0])

    # constraint = my_model.addConstrs(
    #     (((y[i, j].item() == 1) >> (x[np.where(temp_array != i), j].sum() == 0)) for i in range(parameters.number_of_venues)
    #      for j in range(parameters.number_of_courses)),
    #      name="Sec_Constraint_Of_Course_Having_Single_Venue"
    # )

    return constraint


def experimental_constraint(my_model, schedule, parameters : classes.Params):
    x = schedule[:, :, :parameters.venue_types[0], :]
    x = x.sum(axis=2)

    my_model.addConstrs(
        (((x[i, j]*parameters.course_strength).sum() >= (x[i, j + 1]*parameters.course_strength).sum()) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )

    x = schedule[:, :, parameters.venue_types[0]:, :]
    x = x.sum(axis=2)

    my_model.addConstrs(
        (((x[i, j]*parameters.course_strength).sum() <= (x[i, j+1]*parameters.course_strength).sum()) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )

    return


def add_constrs(my_model, schedule, parameters):

    constr_One_Venue_One_Course(my_model, schedule, parameters)
    print("1")

    constrs = constr_No_course_Overlap_Student(my_model, schedule, parameters)
    print("2")

    constr_No_course_Overlap_Professor(my_model, schedule, parameters)
    print("3")

    constr_One_Slot_Course_Once(my_model, schedule, parameters)
    print("4")

    constr_Course_only_Once_a_day(my_model, schedule, parameters)
    print("5")

    constr_venue_setups(my_model, schedule, parameters)
    print("6")

    constr_Total_Credits_of_core_Course(my_model, schedule, parameters)
    print("7")

    constr_Total_lab_hours_of_Course(my_model, schedule, parameters)
    print("8")

    constrs_Allowed_Lab_Time(my_model, schedule, parameters)
    print("9")

    constrs_Non_Minor_Core_Course(my_model, schedule, parameters)
    print("10")

    constrs_Course_Campus(my_model, schedule, parameters)
    print("11")

    constrs_Student_Campus(my_model, schedule, parameters)
    print("12")

    constrs_Professor_Campus(my_model, schedule, parameters)
    print("13")

    print("Primary Constraints done !!!")

    experimental_constraint(my_model, schedule, parameters)
    sec_constrs = []
    # # sec_constrs.append(sec_constrs_non_overlapping_periods(my_model, schedule, parameters))
    print("14")

    sec_constrs.append(sec_constrs_course_having_same_venue(my_model, schedule, parameters))
    print("15")

    # # sec_constrs.append(sec_constrs_core_courses_before_break(my_model, schedule, slots, student_course_priority))
    # # print(12)
    # print("Done !")

    # my_model.update()
    # my_model.tune()
    # return constrs, sec_constrs
    # constrs = []
    return constrs


def print_time_table(my_model, schedule, parameters : classes.Params, file):
    
    print("\nYesssssss!")
    print(f"number_of_working_days : {parameters.number_of_working_days}\n")
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    printing_format = {}
    try:
        for i in range(parameters.number_of_working_days):
            for j in range(parameters.slots):
                # number_of_venues-number_of_labs, 
                for k in range(parameters.number_of_venues):
                    for l in range(parameters.number_of_courses):
                        if my_model.getVarByName('time[%d,%d,%d,%d]' % (i, j, k, l)).X == 1:
                            if parameters.course_list[l] in printing_format:
                                printing_format[parameters.course_list[l]].append(str(days[i]) + str(j+1) + " [" + parameters.venue_dict[parameters.venue_list[k]].name + "]")
                            else:
                                printing_format[parameters.course_list[l]] = [str(days[i]) + str(j+1) + " [" + parameters.venue_dict[parameters.venue_list[k]].name + "]"]
    except:
        try:
            my_model.Params.SolutionNumber = 1
            for i in range(parameters.number_of_working_days):
                for j in range(parameters.slots):
                    # number_of_venues-number_of_labs, 
                    for k in range(parameters.number_of_venues):
                        for l in range(parameters.number_of_courses):
                            if my_model.getVarByName('time[%d,%d,%d,%d]' % (i, j, k, l)).Xn == 1:
                                if parameters.course_list[l] in printing_format:
                                    printing_format[parameters.course_list[l]].append(str(days[i]) + str(j+1) + " [" + parameters.venue_dict[parameters.venue_list[k]].name + "]")
                                else:
                                    printing_format[parameters.course_list[l]] = [str(days[i]) + str(j+1) + " [" + parameters.venue_dict[parameters.venue_list[k]].name + "]"]
        except:
            print("No optimized solution found!")
            return
        
    with  open(file, "w")  as f:
        for course, time in printing_format.items():
            f.write(f"{course} : {', '.join(time)}\n")

    # check.test(schedule, parameters)
                
    return
