from gurobipy import GRB
import gurobipy as gp
import classes
import numpy as np


def obj_same_venue_0(my_model, schedule, parameters : classes.Params, index, priority):
    x1 = schedule[:, :, :parameters.venue_types[0], :].sum(axis=1)
    x1 = x1.sum(axis=0)
    z1 = my_model.addMVar((parameters.venue_types[0], parameters.number_of_courses), vtype=GRB.BINARY)

    my_model.addConstrs(
        (((z1[i, j].item() == 1) >> (x1[i, j] >= np.sum(parameters.course_credits[j][:2])))
         for i in range(parameters.venue_types[0]) for j in range(parameters.number_of_courses)),
         name = "Comditional_Constraint_1"
    )

    my_model.addConstrs(
        (((z1[i, j].item() == 0) >> (x1[i, j] <= 1))
         for i in range(parameters.venue_types[0]) for j in range(parameters.number_of_courses)),
         name = "Comditional_Constraint_2"
    )

    my_model.setObjectiveN(z1.sum(), index=index, priority=priority)
    return


def obj_experimental(my_model, schedule, parameters : classes.Params, index, priority):
    z1 = my_model.addMVar((parameters.number_of_working_days, parameters.slots-1), vtype=GRB.BINARY)
    x1 = schedule[:, :, :parameters.venue_types[0], :]
    x1 = x1.sum(axis=2)

    my_model.addConstrs(
        ( ((z1[i, j].item() == 1) >> ((x1[i, j]*parameters.course_strength).sum() >= (x1[i, j + 1]*parameters.course_strength).sum())) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )
    my_model.addConstrs(
        ( ((z1[i, j].item() == 0) >> ((x1[i, j]*parameters.course_strength).sum() <= (x1[i, j + 1]*parameters.course_strength).sum() - 1)) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )

    z2 = my_model.addMVar((parameters.number_of_working_days, parameters.slots-1), vtype=GRB.BINARY)
    
    x2 = schedule[:, :, parameters.venue_types[0]:, :].sum(axis=3)
    x2 = x2.sum(axis=2)

    # my_model.addConstrs(
    #     ((x2[i, j] <= x2[i, j+1]) for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
    #     name="Experimental Constraint"
    # )

    my_model.addConstrs(
        ( ((z2[i, j].item() == 1) >> ((x2[i, j]*parameters.course_strength).sum() <= (x2[i, j + 1]*parameters.course_strength).sum())) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )
    my_model.addConstrs(
        ( ((z2[i, j].item() == 0) >> ((x2[i, j]*parameters.course_strength).sum() - 1 >= (x2[i, j + 1]*parameters.course_strength).sum())) 
         for i in range(parameters.number_of_working_days) for j in range(parameters.slots - 1)),
        name="Experimental Constraint"
    )

    my_model.setObjectiveN(z1.sum(), index=0, priority=2)
    my_model.setObjectiveN(z2.sum(), index=1, priority=1)

    return


def obj_same_venue_1(my_model, schedule, parameters : classes.Params, index, priority):
    x1 = schedule[:, :, :parameters.venue_types[0], :].sum(axis=1)
    x1 = x1.sum(axis=0)
    z1 = my_model.addMVar((parameters.venue_types[0], parameters.number_of_courses), vtype=GRB.BINARY)

    my_model.addConstrs(
        (((z1[i, j].item() == 1) >> (x1[i, j] >= np.sum(parameters.course_credits[j][:2])))
         for i in range(parameters.venue_types[0]) for j in range(parameters.number_of_courses)),
         name = "Comditional_Constraint_1"
    )

    my_model.addConstrs(
        (((z1[i, j].item() == 0) >> (x1[i, j] <= 1))
         for i in range(parameters.venue_types[0]) for j in range(parameters.number_of_courses)),
         name = "Comditional_Constraint_2"
    )

    my_model.setObjectiveN(z1.sum(), index=index, priority=priority)
    return


def obj_pair_half_semester_courses(my_model, schedule, parameters : classes.Params, index, priority):
    x1 = schedule.sum(axis=3)

    z1 = my_model.addMVar((parameters.number_of_working_days, parameters.slots, parameters.number_of_venues), vtype=GRB.BINARY)

    my_model.addConstrs(
        ( ((z1[i, j, k].item() == 1) >> (x1[i, j, k] == 2)) for i in range(parameters.number_of_working_days) for j in range(parameters.slots) 
         for k in range(parameters.number_of_venues)), name="indic_1"
    )

    my_model.addConstrs(
        ( ((z1[i, j, k].item() == 0) >> (x1[i, j, k] <= 1)) for i in range(parameters.number_of_working_days) for j in range(parameters.slots) 
         for k in range(parameters.number_of_venues)), name="indic_0"
    )

    my_model.setObjectiveN(z1.sum(), index=index, priority=priority)

    return


def obj_maximize_free_slots(my_model, schedule, parameters : classes.Params, index, priority):
    x1 = schedule.sum(axis=3)
    x1 = x1.sum(axis=2)

    z1 = my_model.addMVar((parameters.number_of_working_days, parameters.slots), vtype=GRB.BINARY)
    my_model.addConstrs(
        ((z1[i, j].item() == 1) >> (x1[i, j] == 0) for i in range(parameters.number_of_working_days) for j in range(parameters.slots)),
        name="indic_1"
    )

    my_model.addConstrs(
        ((z1[i, j].item() == 0) >> (x1[i, j] >= 1) for i in range(parameters.number_of_working_days) for j in range(parameters.slots)),
        name="indic_0"
    )

    my_model.setObjectiveN(z1.sum(), index=index, priority=priority)

    return


# def printing_func(my_model, schedule, parameters : classes.Params):
#     if (my_model.status == GRB.OPTIMAL) or (my_model.status == GRB.TIME_LIMIT):
#         try:
#             utils.print_time_table(my_model, schedule, parameters, "test_optimized_time_table.txt")
#         except:
#             print("Optimization done. If you think output could be optimized further try to increase optimization time.")


def add_objectives(my_model, schedule, parameters : classes.Params):
    my_model.ModelSense = GRB.MAXIMIZE
    
    # obj_same_venue_0(my_model, schedule, parameters, 0, 2)
    # obj_experimental(my_model, schedule, parameters, 0, 2) #0,2 1,1
    obj_maximize_free_slots(my_model, schedule, parameters, 0, 1)
    # obj_pair_half_semester_courses(my_model, schedule, parameters, 1, 0)
    my_model.update()
    return
